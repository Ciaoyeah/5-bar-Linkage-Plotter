"""
Webots Five-bar Linkage Ultimate Controller (Supervisor Edition)
Author: Gemini & User
Description:
    1. 整合 Tkinter GUI 用於上傳圖片。
    2. 支援中文路徑讀寫。
    3. [新增] 使用 Supervisor 在 3D 場景中繪製末端軌跡。
    4. [新增] 換圖時自動清除上一張圖的軌跡。
"""

from controller import Supervisor
import numpy as np
import cv2
import os
import math
import time
import shutil
import threading
import tkinter as tk
from tkinter import filedialog

# --- 設定參數區 ---
CONFIG = {
    # 機構參數 (單位: mm)
    "L1": 150.0,       
    "L2": 265.0,       
    "B": 200.0,        
    
    # 座標轉換參數
    "OFFSET_X": 0.0,   
    "OFFSET_Y": 150.0, 
    "WORK_AREA": 200.0,
    
    # 運動控制參數
    "MOVE_SPEED": 1.5, 
    "LOOP_PATH": True, 
    
    # 檔案名稱
    "IMAGE_FILENAME": "draw_target.png",

    # [新增] Supervisor 繪圖設定
    # 如果您的 Webots 世界單位是公尺(m)，而 IK 單位是 mm，請設為 0.001
    # 如果您的 Webots 世界單位直接就是 mm (巨型機器人)，請設為 1.0
    "DRAW_SCALE": 0.001, 
    "DRAW_Z_HEIGHT": 0.01, # 軌跡離地高度 (避免與地面重疊/Z-fighting)
    "DRAW_COLOR": "1 0 0"  # 軌跡顏色 (RGB: 紅色)
}

# 取得當前檔案所在的絕對路徑
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
TARGET_IMAGE_PATH = os.path.join(CURRENT_DIR, CONFIG["IMAGE_FILENAME"])

# ==========================================
# Part 0: 中文路徑支援工具函式
# ==========================================
def cv_imread(file_path):
    try:
        stream = np.fromfile(file_path, dtype=np.uint8)
        cv_img = cv2.imdecode(stream, -1)
        return cv_img
    except Exception as e:
        print(f"[System] cv_imread 錯誤: {e}")
        return None

def cv_imwrite(file_path, img):
    try:
        ext = os.path.splitext(file_path)[1]
        result, n = cv2.imencode(ext, img)
        if result:
            with open(file_path, mode='w+b') as f:
                n.tofile(f)
            return True
        return False
    except Exception as e:
        print(f"[System] cv_imwrite 錯誤: {e}")
        return False

# ==========================================
# Part 1: GUI 介面類別
# ==========================================
class UploaderGUI:
    def __init__(self):
        self.root = None
        self.status_label = None

    def run(self):
        self.root = tk.Tk()
        self.root.title("Webots 圖片控制器")
        self.root.geometry("320x200")
        self.root.attributes('-topmost', True)

        lbl_title = tk.Label(self.root, text="即時更換繪圖路徑", font=("微軟正黑體", 12, "bold"))
        lbl_title.pack(pady=10)

        btn = tk.Button(self.root, text="選擇並上傳圖片", command=self.upload_file, height=2, bg="#ddd", font=("微軟正黑體", 10))
        btn.pack(pady=5, fill='x', padx=20)

        self.status_label = tk.Label(self.root, text="等待操作...", fg="gray", wraplength=280, font=("微軟正黑體", 9))
        self.status_label.pack(pady=10)
        
        lbl_hint = tk.Label(self.root, text=f"目標檔案:\n{CONFIG['IMAGE_FILENAME']}", fg="blue", font=("Arial", 8))
        lbl_hint.pack()

        self.root.mainloop()

    def upload_file(self):
        file_path = filedialog.askopenfilename(
            title="選擇圖片",
            filetypes=[("Images", "*.png;*.jpg;*.jpeg"), ("All Files", "*.*")]
        )
        
        if file_path:
            try:
                shutil.copy(file_path, TARGET_IMAGE_PATH)
                filename = os.path.basename(file_path)
                self.status_label.config(text=f"已更新: {filename}\nWebots 將在幾秒內重繪", fg="green")
                print(f"[GUI] 圖片已更新，來源: {file_path}")
            except Exception as e:
                self.status_label.config(text=f"錯誤: {str(e)}", fg="red")

# ==========================================
# [新增] Part 1.5: TrailDrawer 軌跡繪製器
# ==========================================
class TrailDrawer:
    def __init__(self, supervisor):
        self.supervisor = supervisor
        self.root_node = self.supervisor.getRoot()
        self.children_field = self.root_node.getField("children")
        self.trail_node = None
        self.coord_field = None
        self.index_field = None
        self.point_count = 0
        self.def_name = "ROBOT_TRAIL_PATH"

    def reset_trail(self):
        """ 清除舊軌跡並建立新容器 """
        # 1. 如果已存在舊軌跡，先移除
        existing_node = self.supervisor.getFromDef(self.def_name)
        if existing_node:
            existing_node.remove()
        
        # 2. 建立新的 Shape 字串
        # 使用 IndexedLineSet 來畫線，EmissiveColor 設定線條顏色
        color = CONFIG["DRAW_COLOR"]
        shape_str = f"""
        DEF {self.def_name} Shape {{
          appearance Appearance {{
            material Material {{ diffuseColor {color} emissiveColor {color} }}
          }}
          geometry IndexedLineSet {{
            coord Coordinate {{ point [ ] }}
            coordIndex [ ]
          }}
        }}
        """
        
        # 3. 匯入到世界根目錄
        self.children_field.importMFNodeFromString(-1, shape_str)
        
        # 4. 重新取得欄位引用 (Reference)
        self.trail_node = self.supervisor.getFromDef(self.def_name)
        if self.trail_node:
            geometry = self.trail_node.getField("geometry").getSFNode()
            self.coord_field = geometry.getField("coord").getSFNode().getField("point")
            self.index_field = geometry.getField("coordIndex")
            self.point_count = 0
            print("[Supervisor] 軌跡畫布已重置。")
        else:
            print("[Error] 無法建立軌跡節點！")

    def add_point(self, x_mm, y_mm):
        """ 增加一個點到軌跡中 """
        if self.coord_field is None: return

        # 單位換算: mm -> m
        scale = CONFIG["DRAW_SCALE"]
        z_height = CONFIG["DRAW_Z_HEIGHT"]
        
        # 假設機器人在世界原點，或根據需要加上偏移
        # 這裡直接將 IK 計算出的 (x, y) 畫在世界座標的 (x, y) 平面上
        # Webots 通常 Y 是垂直軸 (Vertical)，X, Z 是水平面
        # 但如果是掛在牆上的 plotter，可能是 X, Y 平面
        # 這裡預設畫在水平地面上 (X, Y對應 Webots的 X, Z? 還是 X, Y?)
        # 嘗試預設: x->x, y->y (垂直平面) 或 x->x, y->z (水平平面)
        # 根據您的 2D 座標習慣，這裡預設畫在 X-Y 平面 (垂直)
        # 如果您的機器人是平躺的，請將下行改成: [x_m, z_height, y_m]
        
        x_m = x_mm * scale
        y_m = y_mm * scale
        
        # [設定] 這裡假設是 X-Y 平面繪圖 (Z 為深度/高度)
        # 如果發現線條畫在空中或方向不對，請調整這裡
        point = [x_m, y_m, z_height] 

        # 1. 寫入點座標
        # 使用 setMFVec3f 的 index -1 代表 append (但在 Python API 有時需指定 index)
        # 更安全的方法是先取得當前數量，但會慢。
        # Webots Python API 的 importMFVec3f 或直接操作：
        
        # 優化：不要每個 step 都呼叫，這裡示範最簡單的直接寫入
        self.coord_field.setMFVec3f(self.point_count, point)
        
        # 2. 連接線段 (Webots IndexedLineSet 需要索引)
        if self.point_count > 0:
            # 連接上一點 (index-1) 到這一點 (index)
            # 格式: [p1, p2, -1, p2, p3, -1 ...] 或連續線段 [p1, p2, p3, -1]
            # 這裡用連續線段，如果 point_count == 1，寫入 [0, 1, -1]
            # 為了動態更新，我們簡單地把新的 index 加入
            # 注意：這在大數據量下可能會變慢，但在 controller step 中通常還好
            
            # 簡單做法：每次加一個點，並將其 index 加入 coordIndex
            # 這樣會形成 p0-p1-p2-p3... 的連續線
            self.index_field.setMFInt32(self.point_count, self.point_count)
            # 注意：IndexedLineSet 預設會把所有點連起來，除非遇到 -1
            # 所以我們只要依序加入 0, 1, 2, 3... 即可
        else:
             self.index_field.setMFInt32(0, 0)

        self.point_count += 1

# ==========================================
# Part 2: 機器人邏輯類別
# ==========================================
class FiveBarKinematics:
    def __init__(self, L1, L2, B):
        self.L1, self.L2, self.B = L1, L2, B

    def ik(self, target_x, target_y):
        d1 = np.linalg.norm([target_x, target_y])
        try:
            cos_a1 = np.clip((self.L1**2 + d1**2 - self.L2**2) / (2 * self.L1 * d1), -1, 1)
            t1 = np.arctan2(target_y, target_x) + np.arccos(cos_a1)
            
            dx2, dy2 = target_x - self.B, target_y
            d2 = np.linalg.norm([dx2, dy2])
            cos_a2 = np.clip((self.L1**2 + d2**2 - self.L2**2) / (2 * self.L1 * d2), -1, 1)
            t2 = np.arctan2(dy2, dx2) - np.arccos(cos_a2)
            return t1, t2
        except: return None

class PathGenerator:
    def __init__(self, image_path, work_size):
        self.image_path = image_path
        self.work_size = work_size
        self.path_points = []
        if not os.path.exists(image_path): self.create_test_image()
        self.process_image()

    def create_test_image(self):
        print("[System] 找不到圖片，生成預設測試圖。")
        img = np.zeros((300, 300), dtype=np.uint8)
        cv2.rectangle(img, (50, 50), (250, 250), 255, 2)
        cv_imwrite(self.image_path, img)

    def process_image(self):
        try:
            original = cv_imread(self.image_path)
            if original is None: return
            
            if len(original.shape) == 3:
                gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
            else:
                gray = original
                
            gray = cv2.flip(gray, 0)
            edges = cv2.Canny(gray, 50, 150)
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            h, w = gray.shape
            scale_x, scale_y = self.work_size / w, self.work_size / h
            self.path_points = []
            
            for cnt in contours:
                epsilon = 0.005 * cv2.arcLength(cnt, True)
                approx = cv2.approxPolyDP(cnt, epsilon, True)
                if len(approx) > 2:
                    for point in approx:
                        px, py = point[0]
                        self.path_points.append((px * scale_x, py * scale_y))
            
            if len(self.path_points) > 0:
                print(f"[System] 圖片讀取成功，共 {len(self.path_points)} 個路徑點。")

        except Exception as e:
            print(f"[System] 影像處理錯誤: {e}")

    def get_path(self): return self.path_points

class RobotController:
    def __init__(self):
        # [修改] 使用 Supervisor 類別
        self.robot = Supervisor()
        self.timestep = int(self.robot.getBasicTimeStep())
        self.motor_left = self.robot.getDevice('motor-a1')
        self.motor_right = self.robot.getDevice('motor-b1')
        self.motor_left.setPosition(float('inf'))
        self.motor_right.setPosition(float('inf'))
        self.motor_left.setVelocity(10.0)
        self.motor_right.setVelocity(10.0)
        
        self.kinematics = FiveBarKinematics(CONFIG["L1"], CONFIG["L2"], CONFIG["B"])
        self.path_gen = PathGenerator(TARGET_IMAGE_PATH, CONFIG["WORK_AREA"])
        self.points = self.path_gen.get_path()
        
        # [新增] 初始化軌跡繪製器
        self.drawer = TrailDrawer(self.robot)
        self.drawer.reset_trail()
        
        self.last_mtime = 0
        if os.path.exists(TARGET_IMAGE_PATH):
            self.last_mtime = os.path.getmtime(TARGET_IMAGE_PATH)

    def check_for_new_image(self):
        try:
            if not os.path.exists(TARGET_IMAGE_PATH): return False
            current_mtime = os.path.getmtime(TARGET_IMAGE_PATH)
            
            if current_mtime > self.last_mtime:
                print(f"\n[System] 偵測到新圖片！正在重新載入...")
                time.sleep(0.5)
                
                self.path_gen.process_image()
                new_points = self.path_gen.get_path()
                
                if new_points and len(new_points) > 0:
                    self.points = new_points
                    self.last_mtime = current_mtime
                    return True
                else:
                    self.last_mtime = current_mtime
        except Exception as e: 
            print(f"[System] 監控錯誤: {e}")
        return False

    def run(self):
        print("Robot Controller Started (Supervisor Mode).")
        curr_idx = 0
        curr_x, curr_y = (0, 0)
        if self.points:
            curr_x, curr_y = self.points[0]

        while self.robot.step(self.timestep) != -1:
            # 1. 監控圖片更新
            if self.check_for_new_image():
                print("[System] 路徑已更新！重置繪圖與軌跡。")
                curr_idx = 0
                # [新增] 換圖時，清除場景中的舊紅線
                self.drawer.reset_trail()
            
            # 2. 執行移動
            if self.points and curr_idx < len(self.points):
                goal_x, goal_y = self.points[curr_idx]
                
                dx = goal_x - curr_x
                dy = goal_y - curr_y
                dist = math.sqrt(dx**2 + dy**2)
                
                speed = CONFIG["MOVE_SPEED"]
                
                if dist <= speed:
                    curr_x, curr_y = goal_x, goal_y
                    curr_idx += 1
                else:
                    ratio = speed / dist
                    curr_x += dx * ratio
                    curr_y += dy * ratio

                # [新增] 畫出當前計算的目標點軌跡
                # 注意：這是 IK 的目標點，我們將它加上 Offset 轉換為絕對座標
                abs_x = curr_x + CONFIG["OFFSET_X"]
                abs_y = curr_y + CONFIG["OFFSET_Y"]
                
                self.drawer.add_point(abs_x, abs_y)
                
                # 執行 IK
                angles = self.kinematics.ik(abs_x, abs_y)
                if angles:
                    self.motor_left.setPosition(angles[0])
                    self.motor_right.setPosition(angles[1])
            
            else:
                if CONFIG["LOOP_PATH"] and self.points:
                    curr_idx = 0
                    # 循環時是否要清除軌跡？
                    # 根據需求：通常循環是重畫，如果不清會越來越多線重疊
                    # 這裡選擇不清，讓它重複描
                    # 如果想清，可以在這裡呼叫 self.drawer.reset_trail()
                else:
                    self.motor_left.setVelocity(0)
                    self.motor_right.setVelocity(0)

if __name__ == "__main__":
    gui_app = UploaderGUI()
    gui_thread = threading.Thread(target=gui_app.run)
    gui_thread.daemon = True 
    gui_thread.start()

    bot = RobotController()
    bot.run()