"""
Webots Five-bar Linkage Ultimate Controller
Author: Gemini & User
Description:
    1. 整合 Tkinter GUI (副執行緒) 用於上傳圖片。
    2. 支援中文路徑讀寫 (解決 OpenCV 亂碼問題)。
    3. 支援熱重載 (Hot Reload)，圖片更新後自動重繪。
    4. 支援恆定速度控制 (Constant Speed Interpolation)。
"""

from controller import Robot
import numpy as np
import cv2
import os
import math
import time
import shutil
import threading
import tkinter as tk
from tkinter import filedialog

# --- 設定參數區 ---
CONFIG = {
    # 機構參數 (單位: mm)
    "L1": 150.0,       # 主臂長度
    "L2": 265.0,       # 副臂長度
    "B": 200.0,        # 兩馬達間距
    
    # 座標轉換參數
    "OFFSET_X": 0.0,   # 繪圖原點相對於左馬達的 X 偏移
    "OFFSET_Y": 150.0, # 繪圖原點相對於左馬達的 Y 偏移
    "WORK_AREA": 200.0,# 工作區域大小 (200x200 mm)
    
    # 運動控制參數
    "MOVE_SPEED": 1.5, # 每個時間步移動的距離 (單位: mm)。數值越大越快。
    "LOOP_PATH": True, # 是否循環繪圖
    
    # 檔案名稱
    "IMAGE_FILENAME": "draw_target.png" 
}

# 取得當前檔案所在的絕對路徑，確保讀寫位置正確 (解決路徑找不到問題)
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
TARGET_IMAGE_PATH = os.path.join(CURRENT_DIR, CONFIG["IMAGE_FILENAME"])

# ==========================================
# Part 0: 中文路徑支援工具函式
# ==========================================
def cv_imread(file_path):
    """ 可讀取中文路徑圖片的替代函式 """
    try:
        # 先用 numpy 讀成二進制串流，再解碼
        stream = np.fromfile(file_path, dtype=np.uint8)
        cv_img = cv2.imdecode(stream, -1) # -1 代表讀取原始格式(含alpha通道等)
        return cv_img
    except Exception as e:
        print(f"[System] cv_imread 錯誤: {e}")
        return None

def cv_imwrite(file_path, img):
    """ 可寫入中文路徑圖片的替代函式 """
    try:
        # 先編碼成副檔名格式，再存成檔案
        ext = os.path.splitext(file_path)[1]
        result, n = cv2.imencode(ext, img)
        if result:
            with open(file_path, mode='w+b') as f:
                n.tofile(f)
            return True
        return False
    except Exception as e:
        print(f"[System] cv_imwrite 錯誤: {e}")
        return False

# ==========================================
# Part 1: GUI 介面類別 (在副執行緒運行)
# ==========================================
class UploaderGUI:
    def __init__(self):
        self.root = None
        self.status_label = None

    def run(self):
        """ 啟動 GUI 視窗 """
        self.root = tk.Tk()
        self.root.title("Webots 圖片控制器")
        self.root.geometry("320x200")
        
        # 讓視窗保持在最上層
        self.root.attributes('-topmost', True)

        lbl_title = tk.Label(self.root, text="即時更換繪圖路徑", font=("微軟正黑體", 12, "bold"))
        lbl_title.pack(pady=10)

        btn = tk.Button(self.root, text="選擇並上傳圖片", command=self.upload_file, height=2, bg="#ddd", font=("微軟正黑體", 10))
        btn.pack(pady=5, fill='x', padx=20)

        self.status_label = tk.Label(self.root, text="等待操作...", fg="gray", wraplength=280, font=("微軟正黑體", 9))
        self.status_label.pack(pady=10)
        
        lbl_hint = tk.Label(self.root, text=f"目標檔案:\n{CONFIG['IMAGE_FILENAME']}", fg="blue", font=("Arial", 8))
        lbl_hint.pack()

        self.root.mainloop()

    def upload_file(self):
        """ 處理檔案上傳與覆蓋 """
        file_path = filedialog.askopenfilename(
            title="選擇圖片",
            filetypes=[("Images", "*.png;*.jpg;*.jpeg"), ("All Files", "*.*")]
        )
        
        if file_path:
            try:
                # 使用 shutil 複製檔案
                shutil.copy(file_path, TARGET_IMAGE_PATH)
                
                filename = os.path.basename(file_path)
                self.status_label.config(text=f"已更新: {filename}\nWebots 將在幾秒內重繪", fg="green")
                print(f"[GUI] 圖片已更新，來源: {file_path}")
            except Exception as e:
                self.status_label.config(text=f"錯誤: {str(e)}", fg="red")

# ==========================================
# Part 2: 機器人邏輯類別 (在主執行緒運行)
# ==========================================
class FiveBarKinematics:
    def __init__(self, L1, L2, B):
        self.L1, self.L2, self.B = L1, L2, B

    def ik(self, target_x, target_y):
        d1 = np.linalg.norm([target_x, target_y])
        try:
            cos_a1 = np.clip((self.L1**2 + d1**2 - self.L2**2) / (2 * self.L1 * d1), -1, 1)
            t1 = np.arctan2(target_y, target_x) + np.arccos(cos_a1)
            
            dx2, dy2 = target_x - self.B, target_y
            d2 = np.linalg.norm([dx2, dy2])
            cos_a2 = np.clip((self.L1**2 + d2**2 - self.L2**2) / (2 * self.L1 * d2), -1, 1)
            t2 = np.arctan2(dy2, dx2) - np.arccos(cos_a2)
            return t1, t2
        except: return None

class PathGenerator:
    def __init__(self, image_path, work_size):
        self.image_path = image_path
        self.work_size = work_size
        self.path_points = []
        
        # 初始檢查：如果沒有圖片，生成一張測試圖
        if not os.path.exists(image_path): 
            self.create_test_image()
        
        # 立即處理一次
        self.process_image()

    def create_test_image(self):
        print("[System] 找不到圖片，生成預設測試圖。")
        img = np.zeros((300, 300), dtype=np.uint8)
        cv2.rectangle(img, (50, 50), (250, 250), 255, 2)
        cv_imwrite(self.image_path, img)

    def process_image(self):
        try:
            # 使用支援中文路徑的讀取函式
            original = cv_imread(self.image_path)
            
            if original is None: 
                # 可能是檔案正在被寫入鎖定中，稍後重試即可，這裡先忽略
                return
            
            # 處理圖片
            if len(original.shape) == 3:
                gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
            else:
                gray = original
                
            gray = cv2.flip(gray, 0) # 翻轉 Y 軸
            
            # 邊緣檢測
            edges = cv2.Canny(gray, 50, 150)
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            h, w = gray.shape
            scale_x, scale_y = self.work_size / w, self.work_size / h
            self.path_points = []
            
            for cnt in contours:
                epsilon = 0.005 * cv2.arcLength(cnt, True)
                approx = cv2.approxPolyDP(cnt, epsilon, True)
                
                # 過濾雜訊點
                if len(approx) > 2:
                    for point in approx:
                        px, py = point[0]
                        self.path_points.append((px * scale_x, py * scale_y))
            
            if len(self.path_points) > 0:
                print(f"[System] 圖片讀取成功，共 {len(self.path_points)} 個路徑點。")

        except Exception as e:
            print(f"[System] 影像處理錯誤: {e}")

    def get_path(self): return self.path_points

class RobotController:
    def __init__(self):
        self.robot = Robot()
        self.timestep = int(self.robot.getBasicTimeStep())
        self.motor_left = self.robot.getDevice('motor-a1')
        self.motor_right = self.robot.getDevice('motor-b1')
        self.motor_left.setPosition(float('inf'))
        self.motor_right.setPosition(float('inf'))
        self.motor_left.setVelocity(10.0)
        self.motor_right.setVelocity(10.0)
        
        self.kinematics = FiveBarKinematics(CONFIG["L1"], CONFIG["L2"], CONFIG["B"])
        self.path_gen = PathGenerator(TARGET_IMAGE_PATH, CONFIG["WORK_AREA"])
        self.points = self.path_gen.get_path()
        
        self.last_mtime = 0
        if os.path.exists(TARGET_IMAGE_PATH):
            self.last_mtime = os.path.getmtime(TARGET_IMAGE_PATH)

    def check_for_new_image(self):
        """ 檢查圖片檔案是否被修改 """
        try:
            if not os.path.exists(TARGET_IMAGE_PATH): return False
            current_mtime = os.path.getmtime(TARGET_IMAGE_PATH)
            
            if current_mtime > self.last_mtime:
                print(f"\n[System] 偵測到新圖片！正在重新載入...")
                time.sleep(0.5) # 等待寫入完成，避免讀到空檔案
                
                self.path_gen.process_image()
                new_points = self.path_gen.get_path()
                
                # 只有當讀到有效的點時才更新
                if new_points and len(new_points) > 0:
                    self.points = new_points
                    self.last_mtime = current_mtime
                    return True
                else:
                    # 如果讀失敗(可能檔案還沒寫完)，只更新時間標記以免重複嘗試
                    self.last_mtime = current_mtime
        except Exception as e: 
            print(f"[System] 監控錯誤: {e}")
        return False

    def run(self):
        print("Robot Controller Started.")
        curr_idx = 0
        
        # 安全初始化：如果沒點，停在原點；有點，停在第一點
        curr_x, curr_y = (0, 0)
        if self.points:
            curr_x, curr_y = self.points[0]

        while self.robot.step(self.timestep) != -1:
            # 1. 監控圖片更新
            if self.check_for_new_image():
                print("[System] 路徑已更新！重置繪圖。")
                curr_idx = 0
                # 這裡不重置 curr_x, curr_y，讓手臂自然移動到新圖的起點
            
            # 2. 執行路徑移動 (Constant Speed)
            if self.points and curr_idx < len(self.points):
                goal_x, goal_y = self.points[curr_idx]
                
                dx = goal_x - curr_x
                dy = goal_y - curr_y
                dist = math.sqrt(dx**2 + dy**2)
                
                speed = CONFIG["MOVE_SPEED"]
                
                # 如果距離小於一步的長度，則直接到達該點
                if dist <= speed:
                    curr_x, curr_y = goal_x, goal_y
                    curr_idx += 1
                else:
                    # 否則只往目標方向移動 speed 的距離
                    ratio = speed / dist
                    curr_x += dx * ratio
                    curr_y += dy * ratio

                # 3. 顯示座標與控制馬達
                print(f"位置：({curr_x:.3f},{curr_y:.3f})")
                
                angles = self.kinematics.ik(curr_x + CONFIG["OFFSET_X"], curr_y + CONFIG["OFFSET_Y"])
                if angles:
                    self.motor_left.setPosition(angles[0])
                    self.motor_right.setPosition(angles[1])
            
            else:
                # 跑完全部路徑後的行為
                if CONFIG["LOOP_PATH"] and self.points:
                    curr_idx = 0 # 循環模式：回到陣列開頭
                else:
                    # 停止模式：停下馬達
                    self.motor_left.setVelocity(0)
                    self.motor_right.setVelocity(0)

# ==========================================
# Part 3: 主程式入口 (啟動雙執行緒)
# ==========================================
if __name__ == "__main__":
    # 1. 建立並啟動 GUI 執行緒 (daemon=True 代表 Webots 關閉時 GUI 也會關閉)
    gui_app = UploaderGUI()
    gui_thread = threading.Thread(target=gui_app.run)
    gui_thread.daemon = True 
    gui_thread.start()

    # 2. 在主執行緒執行 Webots 控制器
    bot = RobotController()
    bot.run()